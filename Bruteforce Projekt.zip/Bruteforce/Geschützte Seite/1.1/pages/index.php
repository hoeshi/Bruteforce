<!DOCTYPE html>    
<html>    
<head>    
    <title>Login Test protected 1.1</title>    
    <link rel="stylesheet" type="text/css" href="css/style.css">    
</head>    
<body>    
    <h2>Login Page</h2><br>    
    <div class="login">    
    <form id="login" method="post" action="index.php">    
        <label><b>Username     
        </b>    
        </label>    
        <input type="text" name="Uname" id="Uname" placeholder="Username">    
        <br><br>    
        <label><b>Password     
        </b>    
        </label>    
        <input type="Password" name="Pass" id="Pass" placeholder="Password" >    
        <br><br>    
        <input type="button" name="log" id="log" value="Login" onClick="pasuser(this.form)">       
        <br><br>    
    </form>     
</div> 

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$name = $_POST["Uname"];
	$pwd = $_POST["Pass"];
	
	if (!(empty($name) and empty($pwd))) {
		
		$connection = new mysqli("127.0.0.1", "php", "1234");

		if ($connection->connect_error) {
			die("Connection failed: " . $connection->connect_error);
		}

		$ip = $_SERVER["REMOTE_ADDR"];
		mysqli_query($connection, "INSERT INTO `login_attempts` (`user`) VALUES ('$ip')");
		$result = mysqli_query($connection, "SELECT COUNT(*) FROM `login_attempts` WHERE `address` LIKE '$ip' AND `timestamp` > (now() - interval 5 minute)");
		$count = mysqli_fetch_array($result, MYSQLI_NUM);

		if($count[0] > 3){
			echo "Your are allowed 3 attempts in 5 minutes";
		} else {
			if ($name == "Admin" and $pwd == "1234") {
				header('Location: right.html');
				die();
			}
		}
	}
}
?>
<script>
var input = document.getElementById("Pass");
input.addEventListener("keyup", function(event) {
  if (event.keyCode === 13) {
   event.preventDefault();
   document.getElementById("log").click();
  }
});
</script>
<script>
var input = document.getElementById("Uname");
input.addEventListener("keyup", function(event) {
  if (event.keyCode === 13) {
   event.preventDefault();
   document.getElementById("log").click();
  }
});
</script>

</body>    
</html> 